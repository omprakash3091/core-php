<?php
// sessions

session_start();

// delete session variable
// unset($_SESSION['visit_counter']);    ye single session variable
session_destroy(); // ye sabhi data ko delete  all session variable kr deta hai

// $_SESSION['course'] = "MCA";
echo "<pre>";
print_r($_SESSION);
// $_SESSION['user'] = "omprakash yadav";

// header('location:/PHP/session/session.php');

// if(isset($_SESSION['visit_counter'])) {
//     $_SESSION['visit_counter'] += 1;
// }else {
// $_SESSION['visit_counter'] = 1;

// }

// $message = "You have visited this page " . $_SESSION['visit_counter'] . "in this session";
// echo $message;
<?php
// sessions

session_start();
if(isset($_SESSION['user'])) {
   echo "Welcome, " . $_SESSION['user'];
}

<?php

// file I/O
/*
- opening a file
- Reading a file
- Writing a file
- Closing a file
 */

 // writing a file

//  $fileName = "docs/content.txt";
//  $file = fopen($fileName,'w');
//  if($file == false){
//     echo "there is some error in file opening";
//  }
//  $filecontent = " Lorem ipsum dolor, sit amet consectetur adipisicing elit. Incidunt repudiandae rerum sapiente ex quisquam ratione modi iste, error deserunt tempora eius saepe voluptate ipsa corporis, eaque fugiat quam totam labore!";
//  fwrite($file, $filecontent);
//  fclose($file);


// Reading a file

$fileName = "docs/content.txt";
$file = fopen($fileName, 'r');
$fileSize = filesize($fileName);
// echo $fileSize . "Bytes";
$content = fread($file, $fileSize);
fclose($file);

echo $content;


<?php
if(isset($_POST['submit'])){

//     echo "<pre>";   ye only chech purpose ke lia use karte hai
//   print_r($_FILES);

$errors = [];
$fileName = $_FILES['filename']['name'];
$file_tem = $_FILES['filename']['tmp_name'];
$file_size =  $_FILES['filename']['size'];
   $arr = explode('.', $fileName);
   $file_extn =  strtolower(end($arr));

$allowedExtns = ["jpf", "jpeg", "png"];

if(!in_array($file_extn, $allowedExtns)){

    $errors[] = "Invalid file Extension. Only jpg, jpeg and png allowed";
}

if($file_size >2097152){
    $errors[] = "File size should not be greater then 2 MB";
}

if(empty($errors)){
     $destination = getcwd() ."Data/". $fileName; 
    if(move_uploaded_file($file_tem, $destination)) {
        echo "File uploaded sucessfully!";
    }else{
        echo "File couldn't be uploaded";
    }
}else{
    echo "<pre>";
    print_r($errors);
}
}


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<form action="" method="POST" enctype="multipart/form-data">
<input type="file" name = "filename">
<input type="submit" name = "submit" value="SUBMIT">


</form>


</body>
</html>
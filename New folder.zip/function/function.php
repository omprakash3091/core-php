
<?php

// Defining a function

// function sayHello(){
//     // function body
//     echo  "Hello World!";
// }

// // function calling

// sayHello() ;
// sayHello();



// Function with Arguments

// function add($num1, $num2)  // is num ko parameter kahate hai
// {
//     $sum = $num1+ $num2;
//     // echo $sum;
//     return $sum;
// }
//    $result = add(3, 5);   // ise arguments kahate hai

//    echo $result;


// using ... access variable arguments

function sum(...$numbers){

   $sum = 0;
   if(!empty($numbers))
   {
    foreach($numbers as $num)
    {
        $sum += $num;
    }
   }
   return $sum;
}

// $result = sum(1, 3, 5, 4, 9, 21, 4);

// echo 'sum = ' .$result;

function add(){
    // $num_args = func_num_args();   -> ye batata hai kitane argument pass kia h
    // echo $num_args;
    $arg = func_get_arg(1);
    echo $arg;
    die();

    $sum =0;
   foreach (func_get_args() as $num){
   $sum += $num; 
   }
   return $sum;
}

$sum = add(4, 5, 6);

echo $sum;

?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>



    
</body>
</html>
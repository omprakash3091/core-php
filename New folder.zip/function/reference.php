
<?php
// passing arguments by value and bu reference

// function show_message(&$msg){

//     $msg.=", Nice to see You";
//     echo $msg;

// }

// $message = "Hello Dere";
// show_message($message);
// echo  "<br>", $message;



// Default Argument values

function show_name($name, $prefix = "Mr."){

    return $prefix."".$name;

}

// $userName = show_name("Pankaj");
$userName = show_name("Monika", "Mrs.");
echo $userName;



<?php
// mysqli,and pdo means(php database object)
// Database Connection

$host = "localhost";
$db_user = "root";
$db_password = "";
$db_name = "phpbasicdb";

$conn = mysqli_connect($host, $db_user, $db_password, $db_name) or 
die("Connection Error: " . mysqli_connect_error());

if($conn){
    
    $sql = "SELECT * FROM `students`";
    $result = mysqli_query($conn, $sql);
    while($row = mysqli_fetch_assoc($result)){
       echo $row['stu_name'], " : ", $row['course'], "</br>";
    }
}

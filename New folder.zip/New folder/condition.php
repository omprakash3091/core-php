<?php

// Conditional statement

// ternary operator

// $a =10;

// echo  $a > 10 ? "Grater then 10" : " Less then 10 or equal to 10 ";

// if statement

// if ($a > 10)
// {
//     echo  "Grater then 10";

// }
// else{
//     echo  "Less then 10 or equal to 10";
// }

// Decision making statement

// $a =10;

// if($a>=10){
//     echo "a is grater then equal to 10";
// }

// $day = date('D');

// if ($day == 'Fri')
// {
//     echo " Weekend is Comming soon!";
// }

// $day = date('D');
// $day = 'Sat';

// if ($day == 'Sun' || $day == 'Sat')
// {
//     echo " Happy Weekend!";
// }
// else if($day == 'Fri')
// {
//     echo " Weekend is comming soon";
// }
// else{
//     echo "WeekDay";
// }

//switch statement 

// $day = date('1');

// switch ($day) {
//     case 'Sunday':
//         echo 'Happy Weeken';
//         break;

// case 'Saturday':
//     echo  "Not Happy Weekend";
//     break;

//     case 'Friday' :
//         echo "Good Weekend";
//         break;

//         default:
//         echo "Weekend is not enjoyed";
//         break;

// }




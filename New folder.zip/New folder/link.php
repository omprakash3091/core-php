<?php

// if(!empty($_GET)){

//     echo $_GET['email'];
// }

if(!empty($_POST)){

   echo $_POST['Name'];
}


// GET and POST Method

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>GET Method</title>

<style>
    .container{
        width: 60%;
        margin: 0 auto;
    }
</style>

</head>
<body>

<div class="container">

<!-- <form action="formation.php" method="GET"> -->
    <form action="formaction.php" method = "POST">

    <!-- <form action="<?php  echo htmlentities($_SERVER["PHP_SELF"])?>"method = "GET"> -->
    <!-- <form action="<?php  echo htmlentities($_SERVER["PHP_SELF"])?>"method = "POST"> -->
    <label for="name">Name</label>
    <input type="text" name="Name" id="Name" value="">
    <br><br>

    <label for="email">Email</label>
    <input type="text" name="email" id="email" value="">
    <br>
    <br>

    <input type="submit" name="submitbtn" id="" value = "SUBMIT">

</form>

</div>
    
</body>
</html>





<?php

// for loop

// for($i =1; $i <= 10; $i++){
//     echo "Number is :", $i;
//     echo "<br>";
// }

// $n =5;

// for( $i = 1; $i<=10; $i++)
// {
//     echo $i * $n, "<br>";
// }

// while loop

// $i =1;

// while($i <=5){

//     echo "Number is :", $i, "<br>";
//     $i++;
// }

// do-while loop

// $i =1;

// do{
//     echo "Number is :", $i, "<br>";
//     $i++;

// }while($i <=5);

// foreach loop this is only use of array

// $arr = array(2, 4, 6, 8);

// foreach($arr as $number) {

//     echo "Number is:", $number, "<br>";
// }

$student  = ["pankaj" => 30, "pawan" =>40, "rohan" =>35];

foreach ($student as $name => $age) {
    echo $name . " : " . $age . "<br>";
}
<?php


//Arrays 

/* 
*  Index Array (numeric Array)
*   Associative Array
*   Multidimentional Array
*/

// Indexed Array

// $arr = array(1, 2, 3, 4,5);

// $arr = array(1, "a", 3.14, 4,5);

// var_dump($arr[4]);

// echo $arr[1];
// array_push($arr ,8);
// array_shift($arr);

// $arr[3] = "Pankaj";
// echo "<pre>";
// print_r($arr);


//  Associate Array

// $marks = ["maths" =>70, "eng" => 75, "sci" => 80];

// var_dump($marks);

// echo $marks ["maths"];

// echo count($marks);


//  MultiDimentional Array

// $student = array(
//     "pankaj"=> array("maths" => 60, "enf" => 70, "sci" =>80),
//     "rohan" => array("maths" =>80, "eng" => 75, "sci" => 80),
//     "suresh" => array("maths" =>70, "eng" => 70, "sci" => 60),
// );


// echo "<pre>";

// $student["pawan"] = array("maths" =>50, "eng" =>70, "sci" =>60);

// // print_r($student);
// // print_r($student ['pankaj']['maths']);

// print_r($student);


// $student = array("Rohan", "Sohan", "Sandeep");
// if(in_array("Sohan2", $student)){

//     echo "Exits";
// }
// else {
//     echo " Doen't Exist";
// }

$student = array("Rohan" => "New Delhi", "Pawan" => "Agra", "Pankaj" => "Noida");

// if(array_key_exists("Pawan" ,$student)){
//     echo "Yes";
// }
// else{
//     echo "No";
// }
// array_unshift( );

// echo count($student);
echo end($student);


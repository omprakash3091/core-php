
<?php


// echo "<pre>";
// var_dump($_GET);

// if(isset($_GET) && $_GET['name'] != ''){

//     echo $_GET['name'];
// }

// if(!empty($_GET)){

//     echo $_GET['Name'];
// }

//Post method

// if(!empty($_POST)){
//     echo $_POST['email'];
// }

// Request Method  -> ye get post and cookies ka information ke data ko store karata hai

if(!empty($_REQUEST)){
    echo $_REQUEST['email'];
}

<?php

// $my_var = 1;
// $my_var2 = 3.14;

// var_dump($my_var2);

// var_dump($my_var);

// echo " $my_var";

// $char = "PHP for Biggners";

// var_dump("$char");

// $bol = true;

// var_dump($bol);

// $null_var = null;

// var_dump($null_var);

// $arr = array(2, 4, 6);
// $arr = [2, 4, 6];

// var_dump($arr);

// $stydent = ["Pankaj" => 30, "Rohit" => 28];

// var_dump($stydent);

class ABC{
    public $name;
    public function fun(){
        return "Hello There";

    }
}

$classObj = new ABC();
var_dump($classObj)
;

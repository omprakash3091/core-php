<?php

// $age =30;
// echo "My Age is :" . $age;

// $a =10;

// if($a==10){
//     echo " this is true";
//     echo " this is second statement";
// }

// echo"Php open with cmd line";

$a=20;
$b =30;
$c =$a+$b;
echo $c . "<br>";

echo $a . "<br>", $b . "<br>", $c . "<br>";




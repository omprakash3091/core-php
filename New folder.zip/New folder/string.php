<?php

//String

// $name = "Pankaj";
// $lastname = "Yadav";
// $fullName = $name . " " .$lastname;
// // var_dump($fullName);
// // echo "$name";

// // echo $fullName;

// echo  strlen($fullName);

// $message = 'Hello there! this is "PHP" String   Tutorial';

// $message = "Hello there! this is \"PHP\" String   Tutorial";

// $message = "Hello there! this is PHP String   Tutorial";

// echo strpos($message, "PHP");
// if(strpos($message, "PHP5") !== false){

//     echo "Found";
// }else{
//     echo "Not Found";
// }


// echo $message;


// $fileName = "profile.php";

// // $extention = substr($fileName, 8);
// $extention = substr($fileName, strlen($fileName) -3);

// echo $extention;

// joining and spliting

// $fruits = "apple, banana, orange";

// echo $fruits;

// explode  string

// $fruitsArr = explode(",", $fruits);

// var_dump($fruitsArr);

$languages = ["PHP", "C", "JAVA", "Python"];
$langList = implode(",", $languages);

var_dump($langList);

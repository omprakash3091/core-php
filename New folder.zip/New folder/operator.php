<?php

// Arithmetic operator

// $a =20;
// $b =10;
// $c= $a + $b;
// $c= $a - $b;
// $c= $a * $b;
// $c= $a / $b;
// $c= $a % $b;

// $a++;
// $a++;
// echo $a;

// Assignment operator


// $a =20;
// $b =10;

//  echo $a += $b;
// echo $a -= $b;
// echo $a *= $b;
// echo $a /= $b;
// echo $a %= $b;

// Comparision operator

// $a =20;
// $b =10;

// if($a == $b)
// {
//     echo "a is equal to b";
// }

// if($a !== $b)
// {
//     echo "a is not equal to b";
// }

// if($a > $b)
// {
//     echo "a is  greater equal to b";
// }

// if($a >= $b)
// {

//     echo "a is grater then equal to b";
// }

// if($a < $b)
// {
//     echo "a is less then to b";
// }

// if($a <= $b)
// {
//     echo "a is less then equal to b";
// }

// Logical Operator

// $a = 10;
// $b = 20;

// if($a or $b) {

//     echo "True";
// }

// if($a and $b) {

//     echo "True";
// }
// if(!$a) {

//     echo "True";
// }


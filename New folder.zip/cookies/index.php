
<?php
// Cookies
// set cookie

// setcookie("name", "Omprakash", time() + 3600);
// setcookie("age", 24, time() + 3600);

// get access cookies

// print_r($_COOKIE['name']);
// print_r($_COOKIE['age']);

// if(isset($_COOKIE['age']));{
//     echo "Hello, " .$_COOKIE['age'];
// }

// delete cookies
// setcookie("name", "pankaj", time() -3600);

// set cookies in Arrays

// setcookie("cookie[one]", "Cookie One");
// setcookie("cookie[two]", "Cookie Two");
// setcookie("cookie[three]", "Cookie Three");

// if(isset($_COOKIE["cookie"]));
// echo "<pre>";
// print_r($_COOKIE["cookie"]);






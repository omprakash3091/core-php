


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About</title>
</head>
<body>
<h1>Award</h1>
    
<?php

include("header1.php");

// require("header.php");
?>


<div>
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officia dignissimos voluptatem neque numquam repudiandae ducimus explicabo sequi iure, nihil itaque? Ducimus fuga repellat repudiandae dicta dolore error at corrupti reprehenderit.
</div>
<?php
include("footer.php");
?>


</body>
</html>
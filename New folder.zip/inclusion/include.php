

<?php
// Inclusion in PHP

//include()
//required()
// include_once()
//require_once().-> multiple file kabhi jud jati hai to pata nhi chalta hai tb ise lagane se function proper work karta hai
// ye dono function use karke hm ak file ke content ko dusare file me use kar sakte hai

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
include("header.php");

?>

<div>
    Lorem ipsum dolor, sit amet consectetur adipisicing elit. Officia dignissimos voluptatem neque numquam repudiandae ducimus explicabo sequi iure, nihil itaque? Ducimus fuga repellat repudiandae dicta dolore error at corrupti reprehenderit.
</div>
<?php
include("footer.php");
?>

</body>
</html>